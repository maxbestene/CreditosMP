# Corsair AI - Landing Page

Una landing page moderna y responsive para Corsair AI Creative Studio, construida a partir de un diseño WordPress/Semplice y optimizada para rendimiento y mantenibilidad.

## 🚀 Características

- **Diseño Responsive**: Adaptado para dispositivos móviles, tablets y desktop
- **Animaciones Suaves**: Efectos de scroll y transiciones elegantes
- **Video Background**: Fondo de video con fallback optimizado
- **Navegación Inteligente**: Menú sticky con efecto de blur en scroll
- **Custom Cursor**: Cursor personalizado para una experiencia única
- **Performance Optimized**: Carga rápida y eficiente

## 📁 Estructura del Proyecto

```
Concepto/
├── index.html              # Página principal
├── css/
│   ├── reset.css          # Reset de estilos base
│   ├── fonts.css          # Definiciones de fuentes
│   ├── main.css           # Estilos principales y variables CSS
│   ├── navigation.css     # Estilos de navegación
│   ├── components.css     # Componentes específicos
│   └── responsive.css     # Media queries y responsive design
├── js/
│   └── main.js           # JavaScript principal con todas las funcionalidades
├── assets/
│   ├── placeholder-logo.svg  # Logo placeholder
│   └── favicon.ico       # Favicon (pendiente)
├── images/               # Directorio para imágenes
└── README.md            # Esta documentación
```

## 🎨 Paleta de Colores

- **Primario**: `#CC33FF` (Púrpura vibrante)
- **Negro**: `#000000` (Fondo principal)
- **Blanco**: `#FFFFFF` (Texto principal)
- **Gris Claro**: `#aaaaaa` (Texto secundario)
- **Gris**: `#777777` (Elementos UI)

## 🔧 Tecnologías Utilizadas

- **HTML5**: Estructura semántica
- **CSS3**: Variables CSS, Flexbox, Grid, Animaciones
- **JavaScript ES6+**: Modules, Intersection Observer API, Modern JS
- **SVG**: Iconos y logos vectoriales

## 📱 Breakpoints Responsive

- **Desktop**: 1170px+
- **Tablet Landscape**: 992px - 1169px
- **Tablet Portrait**: 768px - 991px
- **Mobile Landscape**: 544px - 767px
- **Mobile Portrait**: hasta 543px

## ⚡ Funcionalidades JavaScript

### Navegación
- Menú sticky con efecto blur en scroll
- Navegación móvil con overlay
- Smooth scroll para enlaces internos
- Cierre automático del menú móvil

### Animaciones
- Scroll-triggered animations con Intersection Observer
- Custom cursor con efectos de hover
- Video background con optimización de rendimiento
- Transiciones suaves entre secciones

### Optimizaciones
- Lazy loading de imágenes
- Debounced scroll events
- Video pause cuando no está visible
- Optimización para dispositivos de alta densidad

## 🚀 Cómo Usar

1. **Instalación Simple**:
   ```bash
   # Clona o descarga los archivos
   # Abre index.html en tu navegador
   ```

2. **Servidor Local** (recomendado):
   ```bash
   # Python 3
   python -m http.server 8000
   
   # Python 2
   python -m SimpleHTTPServer 8000
   
   # Node.js
   npx serve .
   ```

3. **Personalización**:
   - Modifica variables CSS en `css/main.css`
   - Cambia contenido en `index.html`
   - Ajusta animaciones en `js/main.js`

## 🎯 Secciones de la Landing

### Hero Section
- Video background con overlay
- Título principal animado
- Call-to-action prominente
- Separador decorativo

### About Section
- Descripción de la empresa
- Texto estructurado con separadores
- Animaciones de entrada escalonadas

### Portfolio/Services Section
- Grid de servicios con layout splitscreen
- Hover effects y transiciones
- Responsive design avanzado

### Contact Section
- Información de contacto
- Enlaces a redes sociales
- Footer con copyright

## 🔧 Personalización

### Cambiar Colores
Edita las variables CSS en `css/main.css`:
```css
:root {
    --color-primary: #CC33FF;
    --color-black: #000000;
    --color-white: #FFFFFF;
    /* ... más variables */
}
```

### Modificar Fuentes
Las fuentes se definen en `css/fonts.css`. Para cambiar la fuente principal:
```css
.font_0phbshn51, 
#content-holder h1, h2, h3, h4, h5, h6 {
    font-family: "tu-fuente", sans-serif;
}
```

### Ajustar Animaciones
Las animaciones se controlan en `js/main.js`:
```javascript
// Modificar timing de animaciones
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};
```

## 📋 TODO / Próximas Mejoras

- [ ] Añadir formulario de contacto funcional
- [ ] Implementar sistema de notificaciones
- [ ] Optimizar carga de fuentes externas
- [ ] Añadir más efectos de parallax
- [ ] Implementar modo oscuro/claro
- [ ] Añadir analytics tracking
- [ ] Optimizar para SEO

## 🐛 Solución de Problemas

### Video no reproduce en móvil
- Verifica que el video tenga los atributos `autoplay muted playsinline`
- Considera añadir un poster image como fallback

### Animaciones no funcionan
- Revisa que JavaScript esté habilitado
- Verifica la consola del navegador para errores
- Asegúrate de que los elementos tengan las clases correctas

### Fuentes no cargan
- Verifica las rutas de las fuentes en `css/fonts.css`
- Considera usar fuentes del sistema como fallback

## 📞 Soporte

Para modificaciones específicas o mejoras, puedes:
1. Modificar directamente los archivos CSS/JS
2. Consultar la documentación de cada sección en los comentarios del código
3. Usar las herramientas de desarrollo del navegador para debugging

## 📄 Licencia

Este proyecto está basado en el diseño original de Corsair AI y ha sido optimizado para uso como landing page independiente.

---

**Versión**: 1.0.0  
**Última actualización**: 2025  
**Compatibilidad**: Navegadores modernos (Chrome 70+, Firefox 65+, Safari 12+, Edge 79+)