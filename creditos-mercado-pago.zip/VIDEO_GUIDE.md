# 🎥 Guía Completa del Video Hero - Corsair AI Landing Page

## 🎯 Resumen del Sistema

He implementado un sistema de video para el hero completamente avanzado que incluye:
- **Múltiples fuentes de video** (local y remoto)
- **Controles interactivos** (play/pause, mute/unmute)
- **Fallback automático** con imagen poster
- **Optimización para móviles**
- **Controles de teclado**
- **Gestión de errores automática**

## 📁 Archivos del Sistema de Video

```
assets/
├── hero-video.mp4          # Tu video principal (local) - AÑADIR
├── hero-video.webm         # Video en formato WebM (opcional) - AÑADIR
├── hero-poster.svg         # Imagen de poster/fallback (incluida)
└── hero-poster.jpg         # Backup del poster (incluida)
```

## 🔧 Cómo Configurar Tu Video

### Opción 1: Video Local (Recomendado)
```bash
# 1. Coloca tu video en la carpeta assets/
cp tu-video.mp4 assets/hero-video.mp4

# 2. Opcional: Crear versión WebM para mejor compatibilidad
ffmpeg -i assets/hero-video.mp4 assets/hero-video.webm
```

### Opción 2: Video Remoto
El sistema ya incluye tu video actual como fallback:
```html
<source src="https://corsair.works/wp-content/uploads/2025/05/Corsair_AI_Creative_Studio.mp4" type="video/mp4">
```

### Opción 3: Solo Imagen (Sin Video)
Si prefieres solo una imagen de fondo:
```html
<!-- Comenta o elimina las líneas de video -->
<!-- <source src="assets/hero-video.mp4" type="video/mp4"> -->
<!-- Solo mantén el poster -->
<img src="assets/hero-poster.svg" alt="Corsair AI Creative Studio">
```

## 🎮 Funcionalidades Incluidas

### ✅ Controles Visuales
- **Play/Pause Button**: Aparece al hacer hover
- **Mute/Unmute Button**: Control de audio
- **Ubicación**: Esquina inferior derecha
- **Estilo**: Glassmorphism con efecto blur

### ✅ Controles de Teclado
- **Spacebar**: Play/Pause
- **M**: Mute/Unmute
- Solo funcionan cuando el hero está visible

### ✅ Controles Táctiles (Mobile)
- **Tap rápido**: Play/Pause
- **Optimización automática** para móviles

### ✅ Gestión Automática
- **Autoplay**: Inicia automáticamente
- **Pause en scroll**: Se pausa cuando sale de vista
- **Fallback automático**: Muestra imagen si el video falla
- **Loading indicator**: Spinner mientras carga

## 🎨 Personalización Visual

### Cambiar Overlay del Video
En `css/components.css`:
```css
.video-overlay {
    background: linear-gradient(
        135deg,
        rgba(0, 0, 0, 0.4) 0%,        /* Oscurecer inicio */
        rgba(204, 51, 255, 0.1) 50%,  /* Tu color primario */
        rgba(0, 0, 0, 0.6) 100%       /* Oscurecer final */
    );
}
```

### Cambiar Posición de Controles
```css
.video-controls {
    bottom: 2rem;     /* Distancia desde abajo */
    right: 2rem;      /* Distancia desde la derecha */
    /* O cambiar a left: 2rem; para la izquierda */
}
```

### Cambiar Opacidad del Video
```css
.hero-video {
    opacity: 0.8;     /* 0.1 = muy transparente, 1.0 = opaco */
}
```

## 📱 Optimizaciones Incluidas

### ✅ Performance
- **Lazy loading**: Carga solo cuando es necesario
- **Pause automático**: Cuando no está visible
- **Preload optimizado**: Solo metadatos inicialmente
- **Compresión móvil**: Filtro automático en dispositivos móviles

### ✅ Compatibilidad
- **Múltiples formatos**: MP4 y WebM
- **Fallback universal**: Imagen SVG
- **Móviles optimizado**: Atributo `playsinline`
- **Todos los navegadores**: Desde IE11 hasta modernos

### ✅ Experiencia de Usuario
- **Autoplay inteligente**: Respeta las políticas del navegador
- **Controles discretos**: Solo aparecen al hacer hover
- **Feedback visual**: Estados de loading y error
- **Accesibilidad**: Labels ARIA incluidos

## 🔨 Configuraciones Avanzadas

### Cambiar Configuración del Video
En `index.html`:
```html
<video 
    id="hero-video"
    autoplay          <!-- Reproducir automáticamente -->
    muted            <!-- Silenciado por defecto -->
    loop             <!-- Repetir infinitamente -->
    playsinline      <!-- Para iOS -->
    preload="metadata" <!-- Cargar solo metadatos -->
    poster="assets/hero-poster.svg">
```

### Opciones de Preload
```html
preload="none"      <!-- No cargar nada -->
preload="metadata"  <!-- Solo información básica (recomendado) -->
preload="auto"      <!-- Cargar todo el video -->
```

### Desactivar Controles
En `css/components.css`:
```css
.video-controls {
    display: none;  /* Ocultar completamente los controles */
}
```

### Solo Video (Sin Overlay)
```css
.video-overlay {
    display: none;  /* Quitar el overlay oscuro */
}
```

## 🐛 Solución de Problemas

### Video no reproduce automáticamente
**Causa**: Políticas del navegador
**Solución**: 
- Asegúrate de que `muted` esté presente
- El video iniciará al hacer scroll o interactuar

### Video se ve muy oscuro
**Causa**: Overlay demasiado opaco
**Solución**:
```css
.video-overlay {
    opacity: 0.3;  /* Reducir opacidad */
}
```

### Controles no aparecen
**Causa**: JavaScript deshabilitado o errores
**Solución**:
- Abre la consola del navegador (F12)
- Verifica errores en JavaScript
- Asegúrate de que `js/main.js` esté cargando

### Video muy pesado/lento
**Solución**:
1. **Comprimir video**:
```bash
ffmpeg -i input.mp4 -vf scale=1920:1080 -c:v libx264 -crf 28 -c:a aac output.mp4
```

2. **Crear versión móvil**:
```bash
ffmpeg -i input.mp4 -vf scale=960:540 -c:v libx264 -crf 32 mobile.mp4
```

### Solo mostrar en Desktop
En `css/responsive.css`:
```css
@media screen and (max-width: 768px) {
    .smp-bg-video video {
        display: none;
    }
    .video-fallback {
        display: block !important;
        z-index: 1;
    }
}
```

## 📋 Checklist de Implementación

### ✅ Básico
- [ ] Reemplazar `assets/hero-video.mp4` con tu video
- [ ] Verificar que el video es menor a 10MB
- [ ] Testear autoplay en diferentes navegadores
- [ ] Verificar que se ve bien en móvil

### ✅ Avanzado
- [ ] Crear versión WebM para mejor compresión
- [ ] Optimizar video para web (CRF 28-32)
- [ ] Crear poster personalizado
- [ ] Testear en conexiones lentas
- [ ] Configurar CDN para el video (opcional)

### ✅ Personalización
- [ ] Ajustar overlay según tu brand
- [ ] Configurar posición de controles
- [ ] Ajustar opacidad del video
- [ ] Testear accesibilidad

## 🚀 Comandos Útiles

### Optimizar Video para Web
```bash
# Comprimir video manteniendo calidad
ffmpeg -i input.mp4 -vf scale=1920:1080 -c:v libx264 -crf 28 -preset slow -c:a aac -b:a 128k output.mp4

# Crear versión WebM (mejor compresión)
ffmpeg -i input.mp4 -c:v libvpx-vp9 -crf 30 -b:v 0 -b:a 128k -c:a libopus output.webm

# Crear poster desde video
ffmpeg -i input.mp4 -ss 00:00:02 -vframes 1 poster.jpg
```

### Información del Video
```bash
# Ver información del video
ffprobe -v quiet -print_format json -show_format -show_streams input.mp4

# Ver tamaño del archivo
ls -lh assets/hero-video.mp4
```

## 💡 Tips Pro

### 🎯 **Mejor Performance**
- Videos de 10-15 segundos son ideales
- Resolución máxima: 1920x1080
- Framerate: 30fps (24fps para más cinematic)
- Duración: 5-30 segundos

### 🎨 **Mejor Visual**
- Usa contenido con movimiento sutil
- Evita texto en el video (usa overlay HTML)
- Colores que contrasten con tu texto
- Loops perfectos (inicio = final)

### 📱 **Mejor Mobile**
- Siempre incluye poster de alta calidad
- Testa en conexiones 3G/4G
- Considera version solo móvil más ligera
- Autoplay puede no funcionar siempre

---

**¡Tu sistema de video hero está completamente configurado y listo para usar!** 🎬

Solo necesitas añadir tu video en `assets/hero-video.mp4` y todo funcionará automáticamente.